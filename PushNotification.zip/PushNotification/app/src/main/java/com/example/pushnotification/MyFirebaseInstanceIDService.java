package com.example.pushnotification;

import android.util.Log;

import com.google.firebase.FirebaseApp;
//import com.google.firebase.events.Subscriber;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.google.firebase.iid.zzan;

import java.util.concurrent.Executor;

public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {


    private static final String TAG = "FirebaseIDService";

    @Override
    public void onTokenRefresh(){

        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.e("token",refreshedToken);

    }


    private void sendRegistrationToServer(String refreshedToken){

    }
}
