package com.example.pushnotification;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;

import com.example.pushnotification.MainActivity;
import com.example.pushnotification.R;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

//import androidx.core.app.NotificationCompat;
//import androidx.core.app.NotificationManagerCompat;

public class MyFirebaseMessagingService extends FirebaseMessagingService {


    public Context mcontext;



    @Override
    public void onMessageReceived(RemoteMessage remoteMessage){

        sendNotification(remoteMessage.getNotification().getBody());
    }


    private void sendNotification(String messageBody){

        Intent intent=new Intent(mcontext, MainActivity.class);

        PendingIntent pendingIntent=PendingIntent.getActivity(mcontext,0,intent,PendingIntent.FLAG_ONE_SHOT);
        NotificationCompat.Builder builder=new NotificationCompat.Builder(mcontext)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("navya")
                .setContentText(messageBody)
                .setContentIntent(pendingIntent);

        NotificationManagerCompat notificationManager=NotificationManagerCompat.from(mcontext);
        notificationManager.notify();

    }
}
